package com.easyapper.bloodline;

public enum FeedbackType {
    COMPLAIN, ISSUE, APPRECIATION, SUGGESTION
}
