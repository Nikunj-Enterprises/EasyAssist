package com.easyapper.bloodline;

public interface LocationReader {
    public float getLangitude();
    public float getLatitude();
}
