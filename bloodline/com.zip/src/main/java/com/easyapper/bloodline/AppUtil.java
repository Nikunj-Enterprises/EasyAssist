package com.easyapper.bloodline;

public class AppUtil {
    public static float calculateDistance(float lat1, float lang1, float lat2, float lang2){
        return 1.5f;
    }
}
